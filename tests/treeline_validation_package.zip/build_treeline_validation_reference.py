#!/usr/bin/env python3
"""Build validation-ready AATE subsets and the treeline evidence inventory.

The script intentionally performs only a provisional broad-region assignment
for AATE points.  Exact assignment to the selected GMBA Basic polygons must be
performed in Earth Engine with ``gee_join_AATE_to_GMBA.js``.
"""

from __future__ import annotations

import csv
import html
import re
import statistics
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
KML_PATH = ROOT / "work/reference_sources/AATE/extracted/doc.kml"
OUT_DIR = ROOT / "deliverables/treeline_validation"


REGION_META = {
    "R1_WET_HIMALAYA": "湿润喜马拉雅",
    "R2_DRY_TIBETAN_PLATEAU": "干旱青藏高原",
    "R3_EUROPEAN_ALPS": "欧洲阿尔卑斯",
    "R4_SCANDINAVIA": "斯堪的纳维亚",
    "R5_ALASKA_YUKON": "阿拉斯加—育空",
    "R6_NORTH_AMERICAN_ROCKIES": "北美落基山",
    "R7_ANDES": "热带和温带安第斯",
    "R8_EAST_AFRICAN_HIGH_MOUNTAINS": "东非高山",
}


MOUNT_TO_REGION = {
    # R1 follows the existing manifest's Central/Eastern/Kumaun proxy.
    "Eastern Himalaya": "R1_WET_HIMALAYA",
    "Central Himalayas": "R1_WET_HIMALAYA",
    "Kumaun Himalayas": "R1_WET_HIMALAYA",
    # R2 is deliberately conservative; the final decision is the GMBA join.
    "Transhimalaya": "R2_DRY_TIBETAN_PLATEAU",
    "Qilian Mountains": "R2_DRY_TIBETAN_PLATEAU",
    "Eastern Alps": "R3_EUROPEAN_ALPS",
    "Western Alps": "R3_EUROPEAN_ALPS",
    "Northern Scandes": "R4_SCANDINAVIA",
    "Southern Scandes": "R4_SCANDINAVIA",
    "Alaska": "R5_ALASKA_YUKON",
    "Saint Elias Mountains": "R5_ALASKA_YUKON",
    "Yukon Intermountain Ranges": "R5_ALASKA_YUKON",
    "Canadian Rockies": "R6_NORTH_AMERICAN_ROCKIES",
    "American Rockies": "R6_NORTH_AMERICAN_ROCKIES",
    "Kilimanjaro": "R8_EAST_AFRICAN_HIGH_MOUNTAINS",
    "Mount Kenya": "R8_EAST_AFRICAN_HIGH_MOUNTAINS",
    "Mount Meru": "R8_EAST_AFRICAN_HIGH_MOUNTAINS",
}


SOURCE_ROWS = [
    {
        "source_id": "AATE_2024",
        "title": "Global Actual Alpine Treeline Elevation (AATE) database",
        "publication_year": 2024,
        "doi": "10.1111/gcb.17260; 10.5281/zenodo.10816403",
        "data_url": "https://zenodo.org/records/10816403",
        "evidence_type": "Google Earth人工判读的最高树木分布点",
        "geometry_type": "point",
        "time_coverage": "点级年份未写入KMZ，需补查影像日期",
        "treeline_definition": "uppermost tree distribution / actual alpine treeline elevation",
        "candidate_region_ids": "ALL_8",
        "independent_from_current_GLAD_pipeline": "mostly_yes",
        "quality_grade": "B",
        "recommended_use": "当前树线上限高程和区域偏差；补齐点级日期后再匹配2020",
        "download_status": "downloaded_and_parsed",
        "key_limit": "最高单株/树木上限不等于0.5 ha连续森林线；无点级年份",
    },
    {
        "source_id": "CLMT_2023",
        "title": "Global closed-loop mountain treeline database",
        "publication_year": 2023,
        "doi": "10.1111/gcb.16885",
        "data_url": "https://hexinyue33.users.earthengine.app/view/clmt",
        "evidence_type": "全球遥感闭合树线产品",
        "geometry_type": "line/database",
        "time_coverage": "2000, 2010",
        "treeline_definition": "closed-loop mountain treeline",
        "candidate_region_ids": "ALL_8",
        "independent_from_current_GLAD_pipeline": "partial",
        "quality_grade": "C",
        "recommended_use": "2000位置及2000—2010移动方向的产品间一致性",
        "download_status": "external_GEE_app",
        "key_limit": "使用全球树覆盖遥感输入；不是2020终点；只覆盖闭合树线",
    },
    {
        "source_id": "ATET_2026",
        "title": "Global Alpine Treeline Elevational Transects v1.0",
        "publication_year": 2026,
        "doi": "10.1038/s41597-026-07293-1; 10.5281/zenodo.10739392",
        "data_url": "https://zenodo.org/records/10739392",
        "evidence_type": "全球树线生态交错带高程样带框架",
        "geometry_type": "polygon_and_centroid",
        "time_coverage": "主要使用2015—2019土地覆盖及长期气候范围",
        "treeline_definition": "broad alpine treeline ecotone transect",
        "candidate_region_ids": "ALL_8",
        "independent_from_current_GLAD_pipeline": "not_applicable",
        "quality_grade": "D",
        "recommended_use": "验证样带布设、生态交错带范围和GMBA组织，不作树线真值",
        "download_status": "metadata_verified_large_dataset",
        "key_limit": "作者明确不是树线形态或精确树线位置清单",
    },
    {
        "source_id": "LU_META_2021",
        "title": "Mountain treelines climb slowly despite rapid climate warming",
        "publication_year": 2021,
        "doi": "10.1111/geb.13214",
        "data_url": "https://data.tpdc.ac.cn/en/data/c050a760-e0f6-4c1d-9cb5-6730449b855d/",
        "evidence_type": "38项研究、143站点的树线移动速率汇编",
        "geometry_type": "site",
        "time_coverage": "1901—2018，各站点不一致",
        "treeline_definition": "literature-specific alpine treeline shift",
        "candidate_region_ids": "R1;R2;R3;R4;R5;R6;R7",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "C",
        "recommended_use": "移动方向和速率量级外部验证；按原研究定义分层",
        "download_status": "manual_download_or_request_required",
        "key_limit": "非2000—2020统一时段；研究间定义和方法异质",
    },
    {
        "source_id": "HARSCH_META_2009",
        "title": "Are treelines advancing? A global meta-analysis",
        "publication_year": 2009,
        "doi": "10.1111/j.1461-0248.2009.01355.x",
        "data_url": "https://onlinelibrary.wiley.com/doi/10.1111/j.1461-0248.2009.01355.x",
        "evidence_type": "166站点树线动态汇编",
        "geometry_type": "site",
        "time_coverage": "1900年以来，各站点不一致",
        "treeline_definition": "literature-specific treeline dynamics",
        "candidate_region_ids": "ALL_8",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "C",
        "recommended_use": "上移/稳定/下移方向一致性和原始文献入口",
        "download_status": "supplement_identified",
        "key_limit": "时间较早；站点不是概率抽样；不宜直接计算2000—2020误差",
    },
    {
        "source_id": "TOTE_2024",
        "title": "ToTE: A global database on trees of the treeline ecotone",
        "publication_year": 2024,
        "doi": "10.1002/ecy.4309",
        "data_url": "https://esajournals.onlinelibrary.wiley.com/doi/10.1002/ecy.4309",
        "evidence_type": "1202项研究的树线树种与文献数据库",
        "geometry_type": "region_and_taxon",
        "time_coverage": "1962—2022文献",
        "treeline_definition": "treeline/near-treeline/upper-montane tree taxa",
        "candidate_region_ids": "ALL_8",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "D",
        "recommended_use": "区域文献检索入口和树线树种核查",
        "download_status": "supplement_identified",
        "key_limit": "不是树线位置或移动几何数据",
    },
    {
        "source_id": "HIMALAYA_TREE_INTERACTION_2021",
        "title": "Tree-to-tree interactions slow down Himalayan treeline shifts",
        "publication_year": 2021,
        "doi": "10.1111/jbi.13840; 10.5061/dryad.n02v6wwt7",
        "data_url": "https://datadryad.org/dataset/doi:10.5061/dryad.n02v6wwt7",
        "evidence_type": "17个喜马拉雅树线样地的树木空间和50年年龄级重建",
        "geometry_type": "plot/site",
        "time_coverage": "约150年重建；论文调查期需逐站核查",
        "treeline_definition": "最高树线与至少30%冠盖度森林线并存",
        "candidate_region_ids": "R1_WET_HIMALAYA",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "A_or_B_after_coordinate_check",
        "recommended_use": "湿润喜马拉雅森林线/最高树线定义差异和移动重建",
        "download_status": "metadata_verified_download_blocked",
        "key_limit": "公开CSV体量很小，需确认是否含四角GPS而非仅汇总量",
    },
    {
        "source_id": "TIBET_PLOTS_2016",
        "title": "Species interactions slow warming-induced upward shifts of treelines on the Tibetan Plateau",
        "publication_year": 2016,
        "doi": "10.1073/pnas.1520582113",
        "data_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC4843427/",
        "evidence_type": "14个青藏高原树线样地、GPS和树龄重建",
        "geometry_type": "plot/site",
        "time_coverage": "1611—2011/2013的50年分段重建",
        "treeline_definition": "最高高度至少2 m树木",
        "candidate_region_ids": "R1_WET_HIMALAYA;R2_DRY_TIBETAN_PLATEAU",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "A_or_B",
        "recommended_use": "青藏高原站点高程及历史移动方向；必须按2 m树线定义比较",
        "download_status": "article_and_supplement_available",
        "key_limit": "不是连续森林线；2000与2020附近没有完全同期的重复观测",
    },
    {
        "source_id": "WEST_US_TREELINE_2023",
        "title": "Potential alpine habitat in the western USA based on treeline elevation",
        "publication_year": 2023,
        "doi": "10.5061/dryad.sqv9s4n9m",
        "data_url": "https://datadryad.org/dataset/doi:10.5061/dryad.sqv9s4n9m",
        "evidence_type": "66个山系268个人工判读树线高程点",
        "geometry_type": "point",
        "time_coverage": "数据发布日期2023；判读影像日期需核查",
        "treeline_definition": "manually identified treeline elevation",
        "candidate_region_ids": "R6_NORTH_AMERICAN_ROCKIES",
        "independent_from_current_GLAD_pipeline": "mostly_yes",
        "quality_grade": "B",
        "recommended_use": "北美落基山树线高程外部验证",
        "download_status": "files_identified",
        "key_limit": "插值得到的潜在高山生境栅格不能当真值；只使用268原始点",
    },
    {
        "source_id": "YUKON_AIRPHOTO_2007",
        "title": "Evidence of Recent Treeline Dynamics in Southwest Yukon from Aerial Photographs",
        "publication_year": 2007,
        "doi": "10.14430/arctic198",
        "data_url": "https://journalhosting.ucalgary.ca/index.php/arctic/article/view/63260",
        "evidence_type": "1947/1948与1989正射航空照片对比",
        "geometry_type": "plots_and_transects",
        "time_coverage": "1947/1948, 1989",
        "treeline_definition": "white spruce abundance and elevational advance",
        "candidate_region_ids": "R5_ALASKA_YUKON",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "B_or_C",
        "recommended_use": "阿拉斯加—育空历史变化案例和方法验证",
        "download_status": "article_available_raw_geometry_uncertain",
        "key_limit": "不对应2000/2020；原始正射影像和矢量未确认开放",
    },
    {
        "source_id": "ITALIAN_ALPS_UAV_2025",
        "title": "Field- and UAV-based treeline observations at ten Italian Alps sites",
        "publication_year": 2025,
        "doi": "10.5194/bg-22-6393-2025",
        "data_url": "https://bg.copernicus.org/articles/22/6393/2025/",
        "evidence_type": "意大利阿尔卑斯10站点野外与UAV树木制图",
        "geometry_type": "tree_points_or_crowns/site",
        "time_coverage": "近2020年代，逐站日期需核查",
        "treeline_definition": "field/UAV tree detection, trees over 50 cm included",
        "candidate_region_ids": "R3_EUROPEAN_ALPS",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "A_after_data_check",
        "recommended_use": "阿尔卑斯高分辨率树木存在和树线生态交错带案例",
        "download_status": "article_verified_data_link_to_check",
        "key_limit": "包含不足3 m幼树，必须按本研究3 m/5 m阈值重筛",
    },
    {
        "source_id": "ROCKIES_WV3_2025",
        "title": "Identifying alpine treeline species using WorldView-3 imagery and CNNs",
        "publication_year": 2025,
        "doi": "10.5194/bg-22-6509-2025; 10.5281/zenodo.14942410",
        "data_url": "https://zenodo.org/records/14942410",
        "evidence_type": "落基山国家公园WorldView-3与实测物种ROI",
        "geometry_type": "ROI_polygon",
        "time_coverage": "WorldView-3: 2020-07-21",
        "treeline_definition": "six treeline tree/shrub species ROIs",
        "candidate_region_ids": "R6_NORTH_AMERICAN_ROCKIES",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "A_for_local_tree_non_tree",
        "recommended_use": "2020年落基山局地树/非树和物种混淆验证",
        "download_status": "open_data_verified",
        "key_limit": "ROI不是完整树线；包含灌木类，需筛选树种",
    },
    {
        "source_id": "THREE_CONTINENTS_SEEDLINGS_2017",
        "title": "Wind and light exposure limit tree-line seedling abundance on three continents",
        "publication_year": 2017,
        "doi": "10.5061/dryad.j0v43",
        "data_url": "https://datadryad.org/dataset/doi:10.5061/dryad.j0v43",
        "evidence_type": "三大洲树线幼苗样地数据",
        "geometry_type": "plot/site",
        "time_coverage": "论文调查期，需核查",
        "treeline_definition": "seedling abundance near tree line",
        "candidate_region_ids": "R6_NORTH_AMERICAN_ROCKIES;R7_ANDES",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "B_for_presence_only",
        "recommended_use": "安第斯和落基山树线生态过程/树木存在辅助验证",
        "download_status": "open_file_identified",
        "key_limit": "幼苗出现不能直接验证3 m或5 m树线",
    },
    {
        "source_id": "EAST_AFRICA_KILIMANJARO_2015",
        "title": "Effects of elevation and land use on biomass at Mount Kilimanjaro",
        "publication_year": 2015,
        "doi": "10.1890/ES14-00492.1",
        "data_url": "https://esajournals.onlinelibrary.wiley.com/doi/10.1890/ES14-00492.1",
        "evidence_type": "乞力马扎罗海拔梯度植被与生物量样地",
        "geometry_type": "plot/site",
        "time_coverage": "论文调查期，需核查",
        "treeline_definition": "elevational vegetation/biomass plots, not a mapped line",
        "candidate_region_ids": "R8_EAST_AFRICAN_HIGH_MOUNTAINS",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "C",
        "recommended_use": "东非高山树/灌/草垂直分带与误判解释",
        "download_status": "article_verified_raw_data_uncertain",
        "key_limit": "不是树线几何；需从样地筛选接近森林上限的记录",
    },
    {
        "source_id": "GLOBAL_MOUNTAIN_LC_VALIDATION_2025",
        "title": "Land cover validation dataset over global mountains",
        "publication_year": 2025,
        "doi": "10.5281/zenodo.15354081",
        "data_url": "https://zenodo.org/records/15354081",
        "evidence_type": "2020年全球山区高分影像判读地表覆盖样本",
        "geometry_type": "point",
        "time_coverage": "2020",
        "treeline_definition": "land-cover classes, not treeline",
        "candidate_region_ids": "ALL_8",
        "independent_from_current_GLAD_pipeline": "yes",
        "quality_grade": "B_for_tree_non_tree_only",
        "recommended_use": "树线邻域内树/非树分类精度辅助验证",
        "download_status": "open_data_verified",
        "key_limit": "样点未专门布设在树线附近，不能单独验证线位置",
    },
]


FIELD_RE = re.compile(r"<td>(FID|LON|LAT|Elevation|contient|Mount)</td>\s*<td>(.*?)</td>", re.S)
TAG_RE = re.compile(r"<[^>]+>")


def clean_html_text(value: str) -> str:
    return html.unescape(TAG_RE.sub("", value)).strip()


def provisional_region(continent: str, mount: str) -> str | None:
    if continent == "South America":
        return "R7_ANDES"
    return MOUNT_TO_REGION.get(mount)


def read_aate_points():
    ns_end = "{http://www.opengis.net/kml/2.2}Placemark"
    for _event, elem in ET.iterparse(KML_PATH, events=("end",)):
        if elem.tag != ns_end:
            continue
        description = elem.findtext("{http://www.opengis.net/kml/2.2}description") or ""
        fields = {key: clean_html_text(value) for key, value in FIELD_RE.findall(description)}
        if not fields:
            elem.clear()
            continue
        region_id = provisional_region(fields.get("contient", ""), fields.get("Mount", ""))
        yield {
            "AATE_FID": int(float(fields["FID"])),
            "LON": float(fields["LON"]),
            "LAT": float(fields["LAT"]),
            "Elevation_m": float(fields["Elevation"]),
            "continent": fields["contient"],
            "AATE_mount": fields["Mount"],
            "region_id_provisional": region_id or "",
            "region_name_zh": REGION_META.get(region_id, ""),
            "source_id": "AATE_2024",
            "observation_year": "",
            "time_match_status": "unknown_point_level_date",
            "treeline_definition": "uppermost_tree_distribution",
            "quality_grade_initial": "B",
        }
        elem.clear()


def quantile(sorted_values, probability: float) -> float:
    if not sorted_values:
        return float("nan")
    position = (len(sorted_values) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(sorted_values) - 1)
    weight = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight


def write_csv(path: Path, rows, fieldnames):
    # Plain UTF-8 keeps GEE's first field name free of a possible BOM marker.
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_aate_outputs():
    rows = list(read_aate_points())
    subset = [row for row in rows if row["region_id_provisional"]]
    fields = list(subset[0])
    write_csv(OUT_DIR / "AATE_8regions_points_provisional.csv", subset, fields)

    by_region = defaultdict(list)
    by_mount = defaultdict(list)
    for row in subset:
        by_region[row["region_id_provisional"]].append(row)
        by_mount[(row["region_id_provisional"], row["AATE_mount"])].append(row)

    summary_rows = []
    for region_id in REGION_META:
        group = by_region.get(region_id, [])
        elevations = sorted(row["Elevation_m"] for row in group)
        mounts = Counter(row["AATE_mount"] for row in group)
        summary_rows.append(
            {
                "region_id": region_id,
                "region_name_zh": REGION_META[region_id],
                "n_points_provisional": len(group),
                "n_AATE_mount_labels": len(mounts),
                "elevation_min_m": min(elevations) if elevations else "",
                "elevation_mean_m": round(statistics.fmean(elevations), 2) if elevations else "",
                "elevation_median_m": round(statistics.median(elevations), 2) if elevations else "",
                "elevation_p05_m": round(quantile(elevations, 0.05), 2) if elevations else "",
                "elevation_p95_m": round(quantile(elevations, 0.95), 2) if elevations else "",
                "elevation_max_m": max(elevations) if elevations else "",
                "AATE_mount_labels": "; ".join(sorted(mounts)),
                "exact_GMBA_match_status": "pending_GEE_spatial_join",
            }
        )
    write_csv(OUT_DIR / "AATE_8regions_summary_provisional.csv", summary_rows, list(summary_rows[0]))

    mount_rows = []
    for (region_id, mount), group in sorted(by_mount.items()):
        elevations = sorted(row["Elevation_m"] for row in group)
        mount_rows.append(
            {
                "region_id": region_id,
                "region_name_zh": REGION_META[region_id],
                "AATE_mount": mount,
                "n_points": len(group),
                "elevation_min_m": min(elevations),
                "elevation_median_m": round(statistics.median(elevations), 2),
                "elevation_max_m": max(elevations),
            }
        )
    write_csv(OUT_DIR / "AATE_8regions_mount_summary.csv", mount_rows, list(mount_rows[0]))
    return len(rows), len(subset)


def build_source_inventory():
    fields = list(SOURCE_ROWS[0])
    write_csv(OUT_DIR / "treeline_reference_source_inventory.csv", SOURCE_ROWS, fields)


def build_blank_gold_template():
    fields = [
        "reference_id",
        "source_id",
        "doi",
        "region_id",
        "GMBA_V2_ID",
        "MapName",
        "longitude",
        "latitude",
        "geometry_type",
        "geometry_source",
        "observation_year",
        "year_start",
        "year_end",
        "target_year",
        "temporal_offset_years",
        "treeline_definition",
        "minimum_tree_height_m",
        "minimum_patch_area_ha",
        "minimum_canopy_cover_pct",
        "species",
        "reference_method",
        "source_resolution_m",
        "horizontal_uncertainty_m",
        "reference_elevation_m",
        "vertical_datum",
        "elevation_source",
        "movement_m",
        "movement_m_per_year",
        "movement_direction",
        "disturbance_status",
        "independent_from_current_GLAD_pipeline",
        "quality_grade",
        "validation_role",
        "license",
        "raw_data_url",
        "notes",
    ]
    write_csv(OUT_DIR / "treeline_validation_gold_template.csv", [], fields)


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    total, selected = build_aate_outputs()
    build_source_inventory()
    build_blank_gold_template()
    print(f"AATE total points: {total}")
    print(f"AATE provisional eight-region points: {selected}")
    print(f"Outputs: {OUT_DIR}")


if __name__ == "__main__":
    main()
