/**
 * Exact spatial join of the public AATE points to the selected GMBA Basic units.
 *
 * Before running:
 * 1. Upload AATE_8regions_points_provisional.csv as a GEE Table asset.
 *    Set X column = LON and Y column = LAT; CRS = EPSG:4326.
 * 2. Confirm the manifest asset path used by code_region_revised.py.
 * 3. Edit the three asset paths below.
 *
 * The provisional region tag in the CSV is only a pre-filter.  The GMBA polygon
 * intersection performed here is the authoritative regional assignment.
 */

var CFG = {
  gmbaAsset: 'projects/ee-remote/assets/Alpine/GMBA_v2',
  manifestAsset: 'projects/ee-wsc/assets/Alpine/GMBA_8regions_Sayre31_32_manifest',
  aateAsset: 'projects/ee-wsc/assets/Alpine/AATE_8regions_points_provisional',
  outputAsset: 'projects/ee-wsc/assets/Alpine/AATE_8regions_GMBA_exact',
  driveFolder: 'GlobalTreeline_validation',
  maxErrorM: 30
};

var REGION_IDS = ee.List([
  'R1_WET_HIMALAYA',
  'R2_DRY_TIBETAN_PLATEAU',
  'R3_EUROPEAN_ALPS',
  'R4_SCANDINAVIA',
  'R5_ALASKA_YUKON',
  'R6_NORTH_AMERICAN_ROCKIES',
  'R7_ANDES',
  'R8_EAST_AFRICAN_HIGH_MOUNTAINS'
]);

function addJoinKey(feature) {
  feature = ee.Feature(feature);
  var key = ee.Number(feature.get('GMBA_V2_ID')).format('%.0f');
  return feature.set('gmba_join_id', key);
}

// Reproduce the manifest-to-GMBA join used by code_region_revised.py.
var gmbaBasic = ee.FeatureCollection(CFG.gmbaAsset)
  .filter(ee.Filter.eq('MapUnit', 'Basic'))
  .map(addJoinKey);

var manifest = ee.FeatureCollection(CFG.manifestAsset).map(addJoinKey);

var selectedGMBA = ee.FeatureCollection(
  ee.Join.saveFirst('manifest_row').apply(
    gmbaBasic,
    manifest,
    ee.Filter.equals({
      leftField: 'gmba_join_id',
      rightField: 'gmba_join_id'
    })
  )
).filter(ee.Filter.notNull(['manifest_row']))
  .map(function(feature) {
    feature = ee.Feature(feature);
    var row = ee.Feature(feature.get('manifest_row'));
    return feature.set({
      region_id: row.get('region_id'),
      region_name: row.get('region_name'),
      region_subtype: row.get('region_subtype'),
      hm31_km2: row.get('hm31_km2'),
      hm32_km2: row.get('hm32_km2'),
      hm_area_km2: row.get('hm_area_km2'),
      hm_fraction: row.get('hm_fraction')
    });
  });

var aate = ee.FeatureCollection(CFG.aateAsset)
  .filter(ee.Filter.inList('region_id_provisional', REGION_IDS));

// AATE is the primary collection so unmatched points can be counted explicitly.
var spatiallyJoined = ee.FeatureCollection(
  ee.Join.saveFirst('gmba_match').apply(
    aate,
    selectedGMBA,
    ee.Filter.intersects({
      leftField: '.geo',
      rightField: '.geo',
      maxError: CFG.maxErrorM
    })
  )
);

var matched = spatiallyJoined
  .filter(ee.Filter.notNull(['gmba_match']))
  .map(function(point) {
    point = ee.Feature(point);
    var gmba = ee.Feature(point.get('gmba_match'));
    var exactRegion = ee.String(gmba.get('region_id'));
    var provisionalRegion = ee.String(point.get('region_id_provisional'));
    var sameRegion = provisionalRegion.compareTo(exactRegion).eq(0);
    return point.set({
      GMBA_V2_ID: gmba.get('GMBA_V2_ID'),
      MapName: gmba.get('MapName'),
      region_id_exact: exactRegion,
      region_name_exact: gmba.get('region_name'),
      region_match_provisional_vs_exact: sameRegion,
      hm31_km2: gmba.get('hm31_km2'),
      hm32_km2: gmba.get('hm32_km2'),
      hm_area_km2: gmba.get('hm_area_km2'),
      hm_fraction: gmba.get('hm_fraction'),
      validation_eligible_position: 1,
      validation_eligible_2020: 0,
      validation_eligible_2000_2020_shift: 0,
      exclusion_reason_temporal: 'AATE KMZ has no point-level observation year'
    }).select([
      'AATE_FID', 'LON', 'LAT', 'Elevation_m', 'continent', 'AATE_mount',
      'source_id', 'observation_year', 'time_match_status',
      'treeline_definition', 'quality_grade_initial',
      'region_id_provisional', 'region_id_exact', 'region_name_exact',
      'region_match_provisional_vs_exact', 'GMBA_V2_ID', 'MapName',
      'hm31_km2', 'hm32_km2', 'hm_area_km2', 'hm_fraction',
      'validation_eligible_position', 'validation_eligible_2020',
      'validation_eligible_2000_2020_shift', 'exclusion_reason_temporal'
    ]);
  });

var elevationReducer = ee.Reducer.count()
  .combine({reducer2: ee.Reducer.mean(), sharedInputs: true})
  .combine({reducer2: ee.Reducer.median(), sharedInputs: true})
  .combine({reducer2: ee.Reducer.percentile([5, 95]), sharedInputs: true})
  .combine({reducer2: ee.Reducer.minMax(), sharedInputs: true});

var exactSummary = ee.FeatureCollection(REGION_IDS.map(function(regionId) {
  regionId = ee.String(regionId);
  var points = matched.filter(ee.Filter.eq('region_id_exact', regionId));
  var stats = points.reduceColumns({
    reducer: elevationReducer,
    selectors: ['Elevation_m']
  });
  return ee.Feature(null, stats).set({
    region_id: regionId,
    n_unique_gmba: points.aggregate_count_distinct('GMBA_V2_ID'),
    n_provisional_mismatch: points
      .filter(ee.Filter.eq('region_match_provisional_vs_exact', 0)).size()
  });
}));

print('Manifest rows', manifest.size());
print('Selected GMBA Basic units', selectedGMBA.size());
print('AATE provisional input points', aate.size());
print('AATE exact GMBA matches', matched.size());
print('AATE outside selected GMBA', aate.size().subtract(matched.size()));
print('Exact counts by region', matched.aggregate_histogram('region_id_exact'));
print('Provisional/exact mismatches',
  matched.filter(ee.Filter.eq('region_match_provisional_vs_exact', 0)).size());
print('Exact regional summary', exactSummary);

Map.centerObject(selectedGMBA, 2);
Map.addLayer(selectedGMBA, {color: '777777'}, 'Selected GMBA Basic', false);
Map.addLayer(matched, {color: '00FFFF'}, 'AATE exact matches', true);

Export.table.toAsset({
  collection: matched,
  description: 'AATE_8regions_GMBA_exact',
  assetId: CFG.outputAsset
});

Export.table.toDrive({
  collection: exactSummary,
  description: 'AATE_8regions_GMBA_exact_summary',
  folder: CFG.driveFolder,
  fileNamePrefix: 'AATE_8regions_GMBA_exact_summary',
  fileFormat: 'CSV'
});
