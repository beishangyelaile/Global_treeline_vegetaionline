# 2000/2020全球高山树线外部验证数据准备

## 1. 本次已经完成的工作

1. 获取并解析公开的 Global Actual Alpine Treeline Elevation（AATE）KMZ。
2. 核实AATE共有55,461个点、77个山系标签。
3. 按当前8类研究区域进行保守的山系级预分类，得到31,660个候选点。
4. 建立树线数据源证据清单和严格验证记录空表。
5. 编写AATE点与当前978个GMBA Basic山体精确空间连接的GEE代码。

AATE论文将该数据描述为基于Google Earth影像人工识别的全球实际高山树线上限；公开KMZ的点级字段只有`FID`、经纬度、`Elevation`、大洲和`Mount`，没有影像或观测年份。因此，它目前能够支持树线上限位置/高程的外部比较，但不能未经补证直接当作2020同期真值，更不能验证2000—2020移动量。

- AATE论文：https://doi.org/10.1111/gcb.17260
- AATE数据：https://doi.org/10.5281/zenodo.10816403

## 2. AATE在8类区域中的初步覆盖

| region_id | 区域 | 候选点数 | 中位高程（m） | 说明 |
|---|---|---:|---:|---|
| R1_WET_HIMALAYA | 湿润喜马拉雅 | 8,232 | 3,968 | Central/Eastern/Kumaun Himalayas |
| R2_DRY_TIBETAN_PLATEAU | 干旱青藏高原 | 7,247 | 4,283 | Transhimalaya、Qilian Mountains |
| R3_EUROPEAN_ALPS | 欧洲阿尔卑斯 | 8,649 | 2,110 | Eastern/Western Alps |
| R4_SCANDINAVIA | 斯堪的纳维亚 | 1,715 | 777 | Northern/Southern Scandes |
| R5_ALASKA_YUKON | 阿拉斯加—育空 | 943 | 1,241 | Alaska、Saint Elias、Yukon Intermountain |
| R6_NORTH_AMERICAN_ROCKIES | 北美落基山 | 543 | 2,113 | American/Canadian Rockies |
| R7_ANDES | 热带和温带安第斯 | 4,181 | 1,955 | AATE中全部南美山地点；待GMBA精确裁剪 |
| R8_EAST_AFRICAN_HIGH_MOUNTAINS | 东非高山 | 150 | 3,384.5 | Kilimanjaro、Mount Kenya、Mount Meru |

这些数量是山系标签预分类结果，不是最终可用样点数。最终数量以点与`GMBA Standard Basic ∩ manifest中的978个山体`精确相交结果为准。

## 3. 文件说明

### `AATE_8regions_points_provisional.csv`

准备上传GEE的31,660个AATE候选点。关键字段：

- `LON`、`LAT`：上传GEE时分别指定为X/Y坐标；
- `Elevation_m`：AATE记录的树线上限高程；
- `AATE_mount`：原数据的山系标签；
- `region_id_provisional`：仅用于预筛，不是最终区域归属；
- `observation_year`：故意留空；
- `time_match_status=unknown_point_level_date`：禁止误作2020同期真值；
- `treeline_definition=uppermost_tree_distribution`。

### `AATE_8regions_summary_provisional.csv`

8类区域的候选点数量和高程分布统计。

### `AATE_8regions_mount_summary.csv`

区域—AATE山系标签层面的数量和高程范围，用于发现错误映射或异常值。

### `treeline_reference_source_inventory.csv`

已有全球数据集、元分析和区域实测数据的证据清单。`quality_grade`含义：

- A：有坐标、日期、实测/UAV/航空或高分辨率几何，定义可与本研究匹配；
- B：有坐标和树线高程，可验证位置/高程，但缺少同期线几何或存在定义差异；
- C：只有站点移动方向、速率或非同期观测；
- D：用于布点、树种核查或算法比较，不能作为树线真值。

### `treeline_validation_gold_template.csv`

严格验证记录的统一字段模板。只有完成原文/补充材料复核的记录才能进入该表。

### `gee_join_AATE_to_GMBA.js`

使用当前GMBA资产和manifest进行精确空间连接，并导出：

- `AATE_8regions_GMBA_exact`点资产；
- `AATE_8regions_GMBA_exact_summary.csv`。

## 4. GEE运行步骤

1. 在GEE Assets上传`AATE_8regions_points_provisional.csv`。
2. 上传参数设置为：X=`LON`，Y=`LAT`，CRS=`EPSG:4326`。
3. 打开`gee_join_AATE_to_GMBA.js`，确认：
   - `gmbaAsset=projects/ee-remote/assets/Alpine/GMBA_v2`；
   - `manifestAsset`与`code_region_revised.py`实际使用的manifest资产一致；
   - `aateAsset`改为刚上传的表资产；
   - `outputAsset`改为有写权限的目标路径。
4. 先运行控制台检查，必须满足：
   - manifest行数为978；
   - selected GMBA Basic数量为978；
   - 8个`region_id_exact`均有匹配点；
   - `region_match_provisional_vs_exact=0`的点要单独检查，不能静默保留。
5. 启动两个Export任务。

精确连接后应使用：

- `region_id_exact`筛选8类区域；
- `GMBA_V2_ID`筛选具体山体；
- 不再使用`AATE_mount`或`region_id_provisional`作为最终研究单元。

## 5. AATE应怎样参与验证

### 可以做

1. 在同一GMBA山体内比较AATE最高树木高程与本研究森林线高程：

   `DeltaZ_definition = Z_AATE_uppermost_tree - Z_extracted_forest_line`

2. 分区域和山体计算中位差、四分位距及异常比例。
3. 检验本研究树线高程的纬度和区域排序是否合理。
4. 识别GLAD 3 m/5 m阈值可能漏掉的稀疏最高树木。

### 暂时不能做

1. 不能计算“2020树线位置MAE”，因为点级影像年份未知。
2. 不能计算2000—2020移动量或移动方向。
3. 不能把AATE最高树木点与0.5 ha连续森林线之间的差值全部解释为提取误差。

如果后续从作者或补充材料获得点级影像日期，则将2018—2022年的点升级为2020匹配候选；仍需保留树线定义差异字段。

## 6. 文献收集的优先顺序

### 第一优先：能形成独立几何或同期点的区域数据

- 喜马拉雅17个树线样地Dryad数据：<https://doi.org/10.5061/dryad.n02v6wwt7>
- 青藏高原14个GPS树线样地：<https://doi.org/10.1073/pnas.1520582113>
- 意大利阿尔卑斯野外/UAV数据：<https://doi.org/10.5194/bg-22-6393-2025>
- 落基山2020年WorldView-3与物种ROI：<https://doi.org/10.5281/zenodo.14942410>
- 西南育空航空照片树线变化：<https://doi.org/10.14430/arctic198>
- 美国西部268个人工树线高程点：<https://doi.org/10.5061/dryad.sqv9s4n9m>

### 第二优先：移动方向和速率数据库

- Lu等143站点树线移动汇编：<https://doi.org/10.1111/geb.13214>
- Harsch等166站点全球元分析：<https://doi.org/10.1111/j.1461-0248.2009.01355.x>

这些记录只能按原研究时间区间验证移动方向/速率量级，不能强制转换为2000—2020同期移动。

### 第三优先：布点和辅助判别

- ATET全球高程样带：<https://doi.org/10.1038/s41597-026-07293-1>
- ToTE树线树种/文献数据库：<https://doi.org/10.1002/ecy.4309>
- 2020全球山区地表覆盖验证点：<https://doi.org/10.5281/zenodo.15354081>

## 7. 最终验证统计设计

应保留三套互不混淆的结果：

1. **同期盲法高分影像验证**：用于报告2000/2020树线位置的主要精度；
2. **实测/航空/UAV外部验证**：用于位置、高程及局地移动；
3. **全球数据集/文献一致性验证**：用于区域排序、方向和速率量级。

建议指标：

- 线位置：平均/中位垂直距离、P90距离、30/60/90 m容差命中率；
- 高程：Bias、MAE、RMSE及中位绝对误差；
- 移动：上移/稳定/下移方向一致率、移动量差、Spearman相关；
- 不确定性：按研究或GMBA山体整组Bootstrap，不能把同一论文的多个点当完全独立样本；
- 防止信息泄漏：调参集与最终验证集必须按整篇研究或整座GMBA山体划分。

## 8. 当前最重要的判断

AATE已经证明8类区域均存在大量外部候选点，但其公开KMZ缺少年份且定义偏向“最高树木上限”。因此，当前正确用法是把它作为B级外部高程基准，并继续用同期高分辨率影像/实测数据承担主要精度验证。已有数据不能取代盲法验证，但能显著扩大空间覆盖并揭示森林线与最高树木线之间的定义差异。

